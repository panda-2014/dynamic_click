
=================
General Functions
=================

position() - Returns tuple of integers: (x, y) for the current position of the mouse cursor.

size() - Returns tuple of integers: (width, height) for size of the main monitor. TODO - add multi monitor support.